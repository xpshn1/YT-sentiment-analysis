import streamlit as st
from fetchComments import raw_comments
from ytSearch import youtube_search
from utils import youtube_search, get_sentiment_summary, clean_comments

st.title("YouTube Comment Sentiment Analysis")

# Section for YouTube video search
st.header("Search YouTube Videos")
query = st.text_input("Enter search query:")

if st.button("Search"):
    results = youtube_search(query)
    st.write(results)

# Section for fetching comments
st.header("Fetch YouTube Comments")
video_id = st.text_input("Enter YouTube Video ID:")

if st.button("Fetch Comments"):
    comments = raw_comments(video_id)
    st.write(comments)

# Section for sentiment analysis
st.header("Analyze Sentiment")
if st.button("Analyze Sentiment"):
    processed_comments = clean_comments(comments)
    sentiments = get_sentiment_summary(processed_comments)
    st.write(sentiments)
