from flask import Flask, render_template, request
from fetchComments import raw_comments
from utils import youtube_search, get_sentiment_summary, clean_comments

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html', results=[])

@app.route("/", methods=['POST'])
def collected_list():
    query = request.form.get('query', '')
    categories = request.form.get('categories', '').split(',')
    categories = [category.strip() for category in categories if category.strip()]

    videos = youtube_search(query)
    video_ids = [video['video_id'] for video in videos]

    comments = raw_comments(video_ids)
    cleaned_comments = clean_comments(comments)
    sentiment_summary = get_sentiment_summary(cleaned_comments, categories)

    # Format results as a list of dictionaries for each video
    results = []
    for video in videos:
        results.append({
            'video_id': video['video_id'],
            'sentiment': sentiment_summary  # Assuming one sentiment summary for all videos
        })
    return render_template('index.html', results=results)

if __name__ == "__main__":
    app.run(debug=True)

